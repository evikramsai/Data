import math
import num
x = int(input("Enter the input : "))
print("Factorial is : ",math.factorial(x))
y = num.array[[1,2,3],[4,5,6],[7,8,9]]
print("Size of the array is : ",y.size)
