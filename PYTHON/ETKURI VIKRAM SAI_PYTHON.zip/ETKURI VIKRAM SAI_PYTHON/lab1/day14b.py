import firstname
import secondname
wholename=firstname().fname+secondname.sname()
