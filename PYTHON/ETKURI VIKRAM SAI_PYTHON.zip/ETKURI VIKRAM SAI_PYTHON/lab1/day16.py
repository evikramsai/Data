list1=[1,2,3,4]
y=0
z=1
for x in list1:
    y=x+y
    z=x*z
print(y)
print(z)
    
