str1=input()
str2=str1.swapcase()

print(str2)
