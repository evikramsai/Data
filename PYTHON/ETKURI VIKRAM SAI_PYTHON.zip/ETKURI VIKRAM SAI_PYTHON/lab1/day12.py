print("give a number")
x=int(input())
print("give the second number")
y=int(input())
z=x+y
print(z)
print(x+y)
if x>y:
    print("x is greater"+str(x))
elif z>y:
    print("z is greater"+str(z))
else :
    print("y is greater "+str(y))
