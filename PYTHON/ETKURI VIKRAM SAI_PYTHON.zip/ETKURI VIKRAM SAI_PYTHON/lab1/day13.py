x=int(input())
y=int(input())
while x!=y:
   print("another number")
   y=int(input())
else:
    print(x)
    
