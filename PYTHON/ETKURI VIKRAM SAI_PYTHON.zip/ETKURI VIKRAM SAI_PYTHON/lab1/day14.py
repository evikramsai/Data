firstname=input()
lastname=input()
wholename=firstname+lastname
print(wholename)
